package com.verity.bolavoz;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Detecta cuando hablas. Si calibraste tu voz, solo reacciona a voces con un
 * tono (pitch) parecido al tuyo y con volumen suficiente.
 */
public class VoiceDetector {

    public interface Listener { void onSpeaking(boolean speaking); }

    static final int SR = 16000;
    static final int FRAME = 1024;
    static final int LAG_MIN = SR / 400; // 400 Hz
    static final int LAG_MAX = SR / 60;  // 60 Hz

    private final SharedPreferences prefs;
    private final Listener listener;
    private volatile boolean running;
    private Thread thread;

    public VoiceDetector(Context c, Listener l) {
        prefs = c.getSharedPreferences("bola", Context.MODE_PRIVATE);
        listener = l;
    }

    public static boolean isCalibrated(Context c) {
        return c.getSharedPreferences("bola", Context.MODE_PRIVATE).getBoolean("calibrated", false);
    }

    public synchronized void start() {
        if (running) return;
        running = true;
        thread = new Thread(this::loop, "voice-detector");
        thread.start();
    }

    public synchronized void stop() {
        running = false;
        if (thread != null) {
            try { thread.join(500); } catch (InterruptedException ignored) {}
            thread = null;
        }
    }

    @SuppressWarnings("MissingPermission")
    private AudioRecord openRecorder() {
        int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SR,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, FRAME * 4));
        if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
            rec.release();
            return null;
        }
        return rec;
    }

    private void loop() {
        AudioRecord rec = openRecorder();
        if (rec == null) return;
        float thr = prefs.getFloat("thr", 0.02f);
        boolean usePitch = prefs.getBoolean("calibrated", false);
        float pMin = prefs.getFloat("pmin", 70f);
        float pMax = prefs.getFloat("pmax", 400f);

        short[] buf = new short[FRAME];
        long lastVoice = 0;
        boolean state = false;
        rec.startRecording();
        try {
            while (running) {
                int n = rec.read(buf, 0, FRAME);
                if (n <= 0) continue;
                float rms = rms(buf, n);
                boolean voice = false;
                if (rms > thr) {
                    if (usePitch) {
                        float p = pitch(buf, n);
                        voice = p > 0 && p >= pMin && p <= pMax;
                    } else {
                        voice = true;
                    }
                }
                long now = System.currentTimeMillis();
                if (voice) lastVoice = now;
                boolean next = (now - lastVoice) < 350; // mantiene la boca abierta un momento
                if (next != state) {
                    state = next;
                    listener.onSpeaking(state);
                }
            }
        } finally {
            try { rec.stop(); } catch (Exception ignored) {}
            rec.release();
        }
    }

    static float rms(short[] b, int n) {
        double s = 0;
        for (int i = 0; i < n; i++) { double v = b[i] / 32768.0; s += v * v; }
        return (float) Math.sqrt(s / n);
    }

    /** Devuelve el tono en Hz, o -1 si no es una voz con tono claro. */
    static float pitch(short[] b, int n) {
        double r0 = 0;
        for (int i = 0; i < n; i++) r0 += (double) b[i] * b[i];
        if (r0 <= 0) return -1;
        double best = 0; int bestLag = -1;
        for (int lag = LAG_MIN; lag <= LAG_MAX; lag++) {
            double s = 0;
            for (int i = 0; i + lag < n; i++) s += (double) b[i] * b[i + lag];
            double r = s / r0;
            if (r > best) { best = r; bestLag = lag; }
        }
        if (best < 0.45 || bestLag < 0) return -1;
        return (float) SR / bestLag;
    }

    public interface CalibProgress { void onStep(String message); }

    /** Calibra con tu voz (bloqueante: llamar desde un hilo). Devuelve null si salió bien, o un mensaje de error. */
    @SuppressWarnings("MissingPermission")
    public static String calibrate(Context c, CalibProgress cb) {
        int min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SR,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, FRAME * 4));
        if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
            rec.release();
            return "No pude abrir el micrófono.";
        }
        short[] buf = new short[FRAME];
        rec.startRecording();
        try {
            cb.onStep("Quédate en silencio 2 segundos...");
            double noise = 0; int cnt = 0;
            long end = System.currentTimeMillis() + 2000;
            while (System.currentTimeMillis() < end) {
                int n = rec.read(buf, 0, FRAME);
                if (n > 0) { noise += rms(buf, n); cnt++; }
            }
            noise = cnt > 0 ? noise / cnt : 0.005;

            cb.onStep("Ahora HABLA normal durante 6 segundos...");
            ArrayList<Float> pitches = new ArrayList<>();
            double rmsSum = 0; int rmsCnt = 0;
            end = System.currentTimeMillis() + 6000;
            while (System.currentTimeMillis() < end) {
                int n = rec.read(buf, 0, FRAME);
                if (n <= 0) continue;
                float r = rms(buf, n);
                if (r > noise * 2.5) {
                    float p = pitch(buf, n);
                    if (p > 0) { pitches.add(p); rmsSum += r; rmsCnt++; }
                }
            }
            if (pitches.size() < 12) return "No te escuché lo suficiente. Habla más fuerte/cerca e intenta otra vez.";
            Collections.sort(pitches);
            float median = pitches.get(pitches.size() / 2);
            float speechRms = (float) (rmsSum / rmsCnt);
            float thr = (float) Math.max(noise * 3.0, speechRms * 0.3);

            c.getSharedPreferences("bola", Context.MODE_PRIVATE).edit()
                    .putBoolean("calibrated", true)
                    .putFloat("thr", thr)
                    .putFloat("pmin", median * 0.75f)
                    .putFloat("pmax", median * 1.30f)
                    .apply();
            return null;
        } finally {
            try { rec.stop(); } catch (Exception ignored) {}
            rec.release();
        }
    }

    public static void clearCalibration(Context c) {
        c.getSharedPreferences("bola", Context.MODE_PRIVATE).edit().clear().apply();
    }
}
