package com.verity.bolavoz;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private ImageView ball;
    private TextView status;
    private Button btnFloat;
    private VoiceDetector local;
    private boolean calibrating = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (12 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        ball = new ImageView(this);
        ball.setImageResource(R.drawable.bola_cerrada);
        ball.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(ball, new LinearLayout.LayoutParams(-1, 0, 1f));

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        status.setPadding(pad, pad, pad, pad);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        Button btnCal = new Button(this);
        btnCal.setText("Calibrar mi voz (solo reaccionar a mí)");
        btnCal.setOnClickListener(v -> calibrar());
        root.addView(btnCal, new LinearLayout.LayoutParams(-1, -2));

        btnFloat = new Button(this);
        btnFloat.setOnClickListener(v -> toggleFloat());
        root.addView(btnFloat, new LinearLayout.LayoutParams(-1, -2));

        Button btnReset = new Button(this);
        btnReset.setText("Quitar calibración (reaccionar a cualquier voz)");
        btnReset.setOnClickListener(v -> {
            VoiceDetector.clearCalibration(this);
            refreshStatus();
            restartLocal();
        });
        root.addView(btnReset, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        requestPerms();
    }

    private void requestPerms() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}, 1);
            else
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        restartLocal();
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void refreshStatus() {
        status.setText(VoiceDetector.isCalibrated(this)
                ? "Voz calibrada: solo reacciona a tu voz"
                : "Sin calibrar: reacciona a cualquier voz");
        btnFloat.setText(BolaService.running ? "Detener bola flotante" : "Iniciar bola flotante (para WhatsApp)");
    }

    private void restartLocal() {
        stopLocal();
        if (!hasMic() || calibrating || BolaService.running) return;
        local = new VoiceDetector(this, speaking -> runOnUiThread(() ->
                ball.setImageResource(speaking ? R.drawable.bola_abierta : R.drawable.bola_cerrada)));
        local.start();
    }

    private void stopLocal() {
        if (local != null) { local.stop(); local = null; }
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); restartLocal(); }
    @Override protected void onPause() { super.onPause(); stopLocal(); }

    private void calibrar() {
        if (!hasMic()) { requestPerms(); return; }
        stopLocal();
        calibrating = true;
        new Thread(() -> {
            String err = VoiceDetector.calibrate(this, msg -> runOnUiThread(() -> status.setText(msg)));
            runOnUiThread(() -> {
                calibrating = false;
                Toast.makeText(this, err == null ? "¡Voz calibrada!" : err, Toast.LENGTH_LONG).show();
                refreshStatus();
                restartLocal();
            });
        }).start();
    }

    private void toggleFloat() {
        if (BolaService.running) {
            startService(new Intent(this, BolaService.class).setAction(BolaService.ACTION_STOP));
            btnFloat.postDelayed(() -> { refreshStatus(); restartLocal(); }, 400);
            return;
        }
        if (!hasMic()) { requestPerms(); return; }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activa el permiso 'Mostrar sobre otras apps' y vuelve a tocar el botón", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        stopLocal();
        startForegroundService(new Intent(this, BolaService.class));
        btnFloat.postDelayed(this::refreshStatus, 400);
    }
}
