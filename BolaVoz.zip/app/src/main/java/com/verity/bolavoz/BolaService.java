package com.verity.bolavoz;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.ImageView;

/** Muestra la bola flotante sobre todas las apps (para compartir pantalla en WhatsApp). */
public class BolaService extends Service {

    public static volatile boolean running = false;
    static final String ACTION_STOP = "com.verity.bolavoz.STOP";

    private WindowManager wm;
    private ImageView view;
    private VoiceDetector detector;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_STICKY;
        running = true;
        startAsForeground();
        showOverlay();
        detector = new VoiceDetector(this, speaking -> ui.post(() -> {
            if (view != null) view.setImageResource(speaking ? R.drawable.bola_abierta : R.drawable.bola_cerrada);
        }));
        detector.start();
        return START_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("bola", "Bola Voz", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, BolaService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, "bola")
                .setSmallIcon(R.drawable.bola_cerrada)
                .setContentTitle("Bola Voz activa")
                .setContentText("Toca para detener la bola flotante")
                .setContentIntent(pi)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
    }

    private void showOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        view = new ImageView(this);
        view.setImageResource(R.drawable.bola_cerrada);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int size = (int) (240 * getResources().getDisplayMetrics().density);
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 40; lp.y = 200;
        view.setOnTouchListener(new android.view.View.OnTouchListener() {
            int sx, sy; float tx, ty;
            @Override public boolean onTouch(android.view.View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx = lp.x; sy = lp.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + (int) (e.getRawX() - tx);
                        lp.y = sy + (int) (e.getRawY() - ty);
                        wm.updateViewLayout(view, lp);
                        return true;
                }
                return false;
            }
        });
        wm.addView(view, lp);
    }

    @Override
    public void onDestroy() {
        running = false;
        if (detector != null) detector.stop();
        if (view != null) { try { wm.removeView(view); } catch (Exception ignored) {} view = null; }
        super.onDestroy();
    }
}
